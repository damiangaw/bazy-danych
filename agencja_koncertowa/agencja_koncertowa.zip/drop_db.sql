DROP TABLE artysta_koncert;
DROP TABLE bilet;
DROP TABLE koncert;
DROP TABLE artysta;
DROP TABLE zespol;
DROP TABLE sala;
DROP TABLE miasto;